import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { PatchCables } from "@/three/cable/PatchCables";
import { SocketField } from "@/three/socket/SocketField";
import { StudioEnv } from "@/three/cable/StudioEnv";
import { ConnectionProvider } from "@/three/connection/ConnectionContext";
import { ResponsiveCamera } from "@/three/ResponsiveCamera";
import { CameraPan } from "@/three/CameraPan";
import { TitleText3D } from "@/three/TitleText3D";
import { FloorGuitar } from "@/three/guitar/FloorGuitar";
import { TITLE_MODE } from "@/config/ui";

/**
 * Owns the R3F <Canvas>. A ResponsiveCamera keeps the composition framed across
 * aspect ratios. The sockets + patch cables live inside the ConnectionProvider
 * so any plug can seat into any socket. Title, pick menu, and HUD are DOM
 * overlays above the canvas.
 */
export function CanvasStage() {
  return (
    <Canvas
      dpr={[1, 2]}
      camera={{ position: [0, 0, 15], fov: 45, near: 0.1, far: 100 }}
      gl={{ antialias: true }}
    >
      <ResponsiveCamera />
      <CameraPan />
      <color attach="background" args={["#0a0a0f"]} />
      <hemisphereLight args={["#8a97ad", "#0c0d12", 0.55]} />
      <directionalLight position={[-4, 6, 6]} intensity={2.1} color="#fff4e6" />
      <directionalLight position={[5, 2, -6]} intensity={1.1} color="#7fb0ff" />
      <StudioEnv />
      {TITLE_MODE === "3d" && (
        <Suspense fallback={null}>
          <TitleText3D />
        </Suspense>
      )}
      {/* Lies on the floor at the bottom of the scroll; mounts itself lazily. */}
      <FloorGuitar />

      <ConnectionProvider>
        <Suspense fallback={null}>
          <PatchCables />
        </Suspense>
        <SocketField />
      </ConnectionProvider>
    </Canvas>
  );
}
