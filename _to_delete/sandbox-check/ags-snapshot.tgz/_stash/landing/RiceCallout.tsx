import { MEDIA } from "@/config/media";

/**
 * Annotation over the festival logo: a dot on Houston, TX with a two-segment
 * "arm" leader line to the Shepherd School of Music at Rice logo (links out).
 *
 * Coordinates are in the logo's own 1122×1402 pixel space. The parent must be a
 * relatively-positioned box with the SAME aspect ratio (1122/1402) so these map
 * 1:1 onto the rendered logo. Tune the three points below to reposition.
 */
const VB_W = 1122;
const VB_H = 1402;

const HOUSTON = { x: 452, y: 322 }; // dot on the upper Texas coast
const ELBOW = { x: 392, y: 270 }; // single bend ("arm")
const JOIN = { x: 300, y: 270 }; // where the label meets the line

const DOT_R = 6; // Houston dot radius (logo units)
const GAP = 14; // space between the arm's tip and the dot (technical-diagram look)
const STROKE = 0.75; // non-scaling line weight (CSS px)

const RICE_URL = "https://music.rice.edu/";

// Stop the arm short of the dot so the line reads as a detached leader.
const _dx = HOUSTON.x - ELBOW.x;
const _dy = HOUSTON.y - ELBOW.y;
const _len = Math.hypot(_dx, _dy);
const TIP = {
  x: HOUSTON.x - (_dx / _len) * (GAP + DOT_R),
  y: HOUSTON.y - (_dy / _len) * (GAP + DOT_R),
};

export function RiceCallout() {
  return (
    <>
      <svg
        viewBox={`0 0 ${VB_W} ${VB_H}`}
        preserveAspectRatio="none"
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          overflow: "visible",
          pointerEvents: "none",
        }}
      >
        <polyline
          points={`${JOIN.x},${JOIN.y} ${ELBOW.x},${ELBOW.y} ${TIP.x.toFixed(1)},${TIP.y.toFixed(1)}`}
          fill="none"
          stroke="#ffffff"
          strokeWidth={STROKE}
          strokeLinejoin="miter"
          strokeLinecap="butt"
          vectorEffect="non-scaling-stroke"
        />
        <circle cx={HOUSTON.x} cy={HOUSTON.y} r={DOT_R} fill="#ffffff" />
      </svg>

      <a
        href={RICE_URL}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e) => e.stopPropagation()}
        style={{
          position: "absolute",
          left: `${(JOIN.x / VB_W) * 100}%`,
          top: `${(JOIN.y / VB_H) * 100}%`,
          transform: "translate(-100%, -99.0%)", // bottom text line sits on the leader line
          paddingRight: "calc(0.4rem - 2px)",
          lineHeight: 0,
          pointerEvents: "auto",
        }}
      >
        <img
          src={MEDIA.shepherdLogo}
          alt="Shepherd School of Music at Rice"
          style={{
            display: "block",
            width: "clamp(5rem, 22cqw, 12rem)",
            height: "auto",
            // Navy artwork on the black landing — knock it out to white so it
            // matches the callout line + festival logo. Delete this filter line
            // to keep the original Rice navy.
            filter: "brightness(0) invert(1)",
          }}
        />
      </a>
    </>
  );
}
